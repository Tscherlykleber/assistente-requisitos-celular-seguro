
# Assistente Inteligente para Apoio à Análise de Requisitos

Este projeto é um MVP desenvolvido para auxiliar analistas de requisitos na identificação, organização e priorização de requisitos de sistemas.

## Funcionalidades
- Upload de requisitos via CSV
- Classificação automática
- Visualização com gráficos
- Estimativa de esforço com regressão
- Sugestão de requisito com IA generativa
- Geração de relatório em PDF

## Como executar
```bash
pip install streamlit pandas matplotlib scikit-learn pymupdf
streamlit run app.py
```

## Estrutura esperada do CSV
- ID
- Descrição
- Tipo (Funcional / Não Funcional)
- Prioridade (Alta / Média / Baixa)
- Complexidade (1 a 5)
- Esforco (horas)
